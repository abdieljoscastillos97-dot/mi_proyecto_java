package starcinema;

public class Administrador {


    private String nombreAdmin;
    private String codigoAcceso;

    public Administrador(String nombre, String codigo) {
        this.setNombreAdmin(nombre);
        this.setCodigoAcceso(codigo);
    }

    public void registrarUsuario(Usuario usuarioActivo, String nombre, String clave) {
        usuarioActivo.setNombre(nombre);
        usuarioActivo.setClave(clave);
        usuarioActivo.setEstado(true);
        System.out.println("Usuario registrado: " + nombre);
    }

    public void configurarSistema(LogicaSistema logica, double precioEntrada, double precioCombo, int boletos, int combos) {
        logica.precioEntradaCine = precioEntrada;
        logica.precioComboDulces = precioCombo;
        logica.stockBoletos = boletos;
        logica.stockCombos = combos;
        System.out.println("Sistema configurado correctamente");
    }

	public String getNombreAdmin() {
		return nombreAdmin;
	}

	public void setNombreAdmin(String nombreAdmin) {
		this.nombreAdmin = nombreAdmin;
	}

	public String getCodigoAcceso() {
		return codigoAcceso;
	}

	public void setCodigoAcceso(String codigoAcceso) {
		this.codigoAcceso = codigoAcceso;
	}
}
