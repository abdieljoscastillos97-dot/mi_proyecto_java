package starcinema;

public class LogicaSistema {

	    double precioEntradaCine;
	    double precioComboDulces;
	    int stockBoletos;
	    int stockCombos;

	    public LogicaSistema() {
	        this.precioEntradaCine = 5.00;  
	        this.precioComboDulces = 3.50;  
	        this.stockBoletos = 100;        
	        this.stockCombos = 50;          
	    }

	   
	    public void mostrarPrecios() {
	        System.out.println("Precio entrada cine: $" + precioEntradaCine);
	        System.out.println("Precio combo dulces: $" + precioComboDulces);
	        System.out.println("Stock boletos: " + stockBoletos);
	        System.out.println("Stock combos: " + stockCombos);
	}
}
