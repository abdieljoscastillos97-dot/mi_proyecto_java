package starcinema;

public class Usuario {

    private String nombreUsuario;
    private String clave;
    private boolean estado;
    private int comprasRealizadas;
    private double totalVendido;

    public Usuario() {
        this.estado = false; 
        this.comprasRealizadas = 0;
        this.totalVendido = 0.0;
    }

    public String getNombre() { return nombreUsuario; }
    public void setNombre(String nombre) { this.nombreUsuario = nombre; }

    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }

    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }

    public boolean validarAcceso() {
        if (estado == true && nombreUsuario != null && clave != null) {
            return true;
        } else {
            return false;
        }
    }

    public void realizarVenta(LogicaSistema logica, int boletos, int combos) {
        double total = (boletos * logica.precioEntradaCine) + (combos * logica.precioComboDulces);
        logica.stockBoletos -= boletos;
        logica.stockCombos -= combos;
        comprasRealizadas++;
        totalVendido += total;
        System.out.println("Venta realizada. Total: $" + total);
    }

    public void mostrarPerfil() {
        System.out.println("Perfil del Usuario:");
        System.out.println("Nombre: " + nombreUsuario);
        System.out.println("Compras realizadas: " + comprasRealizadas);
        System.out.println("Total vendido: $" + totalVendido);
    }
}