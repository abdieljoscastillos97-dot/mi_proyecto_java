package starcinema;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);

	        Encabezado encabezado = new Encabezado();
	        LogicaSistema logica = new LogicaSistema();
	        Administrador admin = new Administrador("Admin1", "1234");
	        Usuario usuario = new Usuario();

	        int opcion;

	        do {
	            encabezado.mostrarEncabezado();
	            encabezado.mostrarMenu();
	            System.out.print("Seleccione una opción: ");
	            opcion = scanner.nextInt();
	            scanner.nextLine(); 

	            switch (opcion) {
	                case 1: 
	                    System.out.println("\n--- SECCIÓN ADMINISTRACIÓN ---");
	                    System.out.print("Ingrese código de acceso: ");
	                    
	                    String codigo = scanner.nextLine();

	                    if (codigo.equals("1234")) {
	                        System.out.println("1. Registrar/Modificar Usuario");
	                        System.out.println("2. Configurar Parámetros Globales");
	                        System.out.print("Seleccione: ");
	                        int opAdmin = scanner.nextInt();
	                        scanner.nextLine();

	                        if (opAdmin == 1) {
	                            System.out.print("Nombre del usuario: ");
	                            String nombre = scanner.nextLine();
	                            System.out.print("Clave del usuario: ");
	                            String clave = scanner.nextLine();
	                            admin.registrarUsuario(usuario, nombre, clave);
	                        } else if (opAdmin == 2) {
	                            System.out.print("Nuevo precio entrada: ");
	                            double precioEnt = scanner.nextDouble();
	                            System.out.print("Nuevo precio combo: ");
	                            double precioCombo = scanner.nextDouble();
	                            System.out.print("Stock boletos: ");
	                            int stockB = scanner.nextInt();
	                            System.out.print("Stock combos: ");
	                            int stockC = scanner.nextInt();
	                            admin.configurarSistema(logica, precioEnt, precioCombo, stockB, stockC);
	                        }
	                    } else {
	                        System.out.println("Código incorrecto");
	                    }
	                    break;

	                case 2: 
	                    System.out.println("\n--- SECCIÓN REPORTES ---");
	                    logica.mostrarPrecios();
	                    usuario.mostrarPerfil();
	                    break;

	                case 3:
	                    System.out.println("\n--- SECCIÓN CLIENTE/USUARIO ---");
	                    if (usuario.validarAcceso()) {
	                        System.out.println("Acceso concedido a: " + usuario.getNombre());
	                        System.out.print("Cantidad de boletos: ");
	                        int boletos = scanner.nextInt();
	                        System.out.print("Cantidad de combos: ");
	                        int combos = scanner.nextInt();
	                        usuario.realizarVenta(logica, boletos, combos);
	                    } else {
	                        System.out.println("Acceso denegado. El administrador no ha registrado este usuario.");
	                    }
	                    break;

	                case 4:
	                    System.out.println("Saliendo del sistema...");
	                    break;

	                default:
	                    System.out.println("Opción no válida");
	            }

	            System.out.println("\nPresione Enter para continuar...");
	            scanner.nextLine();

	        } while (opcion != 4);

	        scanner.close();
		// TODO Auto-generated method stub

	}

}
