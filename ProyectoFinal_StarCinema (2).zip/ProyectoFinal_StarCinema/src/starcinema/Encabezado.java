package starcinema;

public class Encabezado {
	   
	    public void mostrarEncabezado() {
	        System.out.println("============================================");
	        System.out.println("   UNIVERSIDAD TECNOLÓGICA DE PANAMÁ");
	        System.out.println("   Centro Regional de Chiriquí");
	        System.out.println("   Materia: Desarrollo de Software 2");
	        System.out.println("   Semestre: 2-2026");
	        System.out.println("   Profesor: Jaime Palacios");
	        System.out.println("   Estudiante: Abdiel Castillo");
	        System.out.println("============================================");
	        System.out.println("   PROYECTO: StarCinema Studios");
	        System.out.println("============================================");
	    }

	    
	    public void mostrarMenu() {
	        System.out.println("\n--- MENÚ PRINCIPAL ---");
	        System.out.println("1. Sección Administración");
	        System.out.println("2. Sección Reportes");
	        System.out.println("3. Sección Cliente o Usuario");
	        System.out.println("4. Salir del Sistema");
	        System.out.println("----------------------");
	    
	}
}
